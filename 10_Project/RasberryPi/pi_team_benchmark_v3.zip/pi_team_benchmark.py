#!/usr/bin/env python3
"""Full-video benchmark using the team's reconstructed evaluation protocol."""
import argparse
import csv
import hashlib
import json
import math
import os
import signal
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

from benchmark_common import (ROOT, COMMIT, VERSION, RunLock, atomic_json, hardware,
    package_versions, peak_rss_mb, recover_rows, sha256, stats, synchronize, thermal)
from evaluation import analyse, make_plan, validate_config, write_reports, zone_conf

STOP = False
SNAPSHOT = False


def source_info(source, cv2):
    cap = cv2.VideoCapture(str(source))
    try:
        v = {'fps':cap.get(cv2.CAP_PROP_FPS), 'frame_count':int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),
             'width':int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), 'height':int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}
        if not cap.isOpened() or v['fps'] <= 0 or v['frame_count'] <= 0:
            raise ValueError('영상의 FPS/프레임 수를 읽을 수 없습니다')
        v['duration_s'] = v['frame_count'] / v['fps']
        return v
    finally:
        cap.release()


def read_targets(source, plan, cv2):
    cap = cv2.VideoCapture(str(source))
    index = 0
    try:
        for ordinal,target in enumerate(plan):
            if ordinal == 0 and target['index'] > 0:
                # Repositioning after resume is setup, not the next frame's decode cost.
                while index < target['frame_index']:
                    if not cap.grab():
                        raise ValueError(f"재개 위치 이동이 프레임 {index}에서 끝났습니다")
                    index += 1
            begin = time.perf_counter()
            while index <= target['frame_index']:
                if not cap.grab():
                    raise ValueError(f"영상이 프레임 {index}에서 끝났습니다")
                index += 1
            ok, frame = cap.retrieve()
            if not ok:
                raise ValueError(f"프레임 {target['frame_index']} 디코딩 실패")
            yield target, frame, (time.perf_counter()-begin)*1000
    finally:
        cap.release()


def prepare_jpegs(source, plan, folder, cv2):
    cache = folder/'frames'
    cache.mkdir(exist_ok=True)
    for p, frame, _ in read_targets(source, plan, cv2):
        path = cache/f"frame_{p['frame_index']:07d}.jpg"
        if not cv2.imwrite(str(path), frame):
            raise OSError(f'JPEG 저장 실패: {path}')
        with open(path, 'rb') as f:
            os.fsync(f.fileno())
        p['jpeg_path'], p['jpeg_sha256'] = str(path), sha256(path)


def digest(settings):
    keys = ('config','weights_sha256','source_sha256','video','reference_ok','plan','device','threads',
            'expected_model_yaml','code_sha256','packages','hardware','protocol_version')
    payload = {k:settings[k] for k in keys}
    return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()


def validate_rows(rows, settings):
    plan = settings['plan']
    if len(rows) > len(plan):
        raise ValueError('표본 수가 평가 계획보다 많습니다')
    for r, p in zip(rows, plan):
        if (r['index'],r['frame_index'],r['roles']) != (p['index'],p['frame_index'],p['roles']) or abs(r['time_s']-p['time_s']) > 1e-6:
            raise ValueError('저장된 표본이 공통 평가 계획과 다릅니다')
        if r.get('signature') != settings['signature']:
            raise ValueError('다른 시험의 원시 기록이 섞였습니다')
        for k in ('predict_ms','pipeline_ms'):
            if not isinstance(r.get(k),(int,float)) or not math.isfinite(r[k]) or r[k] < 0:
                raise ValueError('처리시간 기록 손상')
        if not isinstance(r.get('detections'),list):
            raise ValueError('탐지 기록 손상')


def pack_results(folder):
    target = folder.with_suffix('.zip')
    tmp = target.with_name(target.name+'.tmp')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(folder.rglob('*')):
            rel = p.relative_to(folder)
            if p.is_file() and 'frames' not in rel.parts and p.name not in ('run.lock','pid.txt') and not p.name.endswith('.tmp'):
                z.write(p,str(Path(folder.name)/rel))
    os.replace(tmp,target)
    return target


def save_results(folder,settings,rows,status,sessions,model_info,error=None):
    analysis = analyse(rows,settings)
    timeline = analysis.pop('timeline')
    summary = {'program_version':VERSION,'protocol_version':settings['protocol_version'],'status':status,'error':error,
               'model':model_info,'samples':len(rows),'expected_samples':len(settings['plan']),
               'analysis':analysis,'sessions':sessions}
    atomic_json(folder/'summary.json',summary)
    atomic_json(folder/'metadata.json',{'settings':settings,'sessions':sessions,'model':model_info})
    fields = ['index','frame_index','time_s','roles','predict_ms','model_inference_ms','pipeline_ms','confidence','peak_rss_mib','temperature_c']
    with open(folder/'results.csv','w',newline='',encoding='utf-8-sig') as f:
        w = csv.DictWriter(f,fields)
        w.writeheader()
        for r in rows:
            item = {k:r.get(k) for k in fields}
            item['roles'] = ';'.join(r['roles'])
            w.writerow(item)
    with open(folder/'timeline.csv','w',newline='',encoding='utf-8-sig') as f:
        fields = ['frame_index','time_s','confidence','present','state','streak','last_seen_s','team_absence_s','continuous_absence_s']
        w = csv.DictWriter(f,fields)
        w.writeheader()
        w.writerows(timeline)
    write_reports(folder,summary,settings)
    return summary, pack_results(folder)


def parse(argv):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--version',action='version',version=f'pi_team_benchmark {VERSION} | protocol=team-video-3.0')
    p.add_argument('--weights',default='best26s_v2.pt')
    p.add_argument('--source',default='../benchmark/test.mp4')
    p.add_argument('--config',default=str(ROOT/'team_config.json'))
    p.add_argument('--input-mode',choices=('jpeg','video'))
    p.add_argument('--device',default='cpu')
    p.add_argument('--threads',type=int,help='생략 시 라이브러리 정책; 지정 시 워밍업 후 실제 추론에 적용')
    p.add_argument('--expected-model-yaml',default='yolo26s.yaml')
    p.add_argument('--label',help='다른 모델 비교 시 표에 사용할 이름')
    p.add_argument('--out',default='results_team')
    p.add_argument('--resume',help='버전 3 전체 평가 결과 폴더')
    p.add_argument('--save-only',action='store_true')
    p.add_argument('--check',action='store_true')
    return p.parse_args(argv)


def check_resume_files(s):
    if digest(s) != s['signature']:
        raise ValueError('공통 평가 설정이 변경되었습니다')
    if s['hardware'] != hardware() or s['packages'] != package_versions():
        raise ValueError('실행 장치 또는 패키지 버전이 달라졌습니다')
    if sha256(s['weights']) != s['weights_sha256'] or sha256(s['source']) != s['source_sha256']:
        raise ValueError('모델 또는 영상 파일이 변경되었습니다')
    for name,expected in s['code_sha256'].items():
        if sha256(ROOT/name) != expected:
            raise ValueError(f'평가 코드가 변경되었습니다: {name}')
    if s['config']['input_mode'] == 'jpeg':
        for p in s['plan']:
            if sha256(p['jpeg_path']) != p['jpeg_sha256']:
                raise ValueError('평가 JPEG가 변경되었습니다')


def main(argv=None):
    global STOP,SNAPSHOT
    STOP,SNAPSHOT = False,False
    args = parse(argv)
    if args.save_only and not args.resume:
        raise ValueError('--save-only는 --resume과 함께 사용하세요')
    os.environ.setdefault('YOLO_AUTOINSTALL','false')
    if args.check:
        import cv2,torch,ultralytics
        print(json.dumps({'hardware':hardware(),'packages':package_versions(),'thermal':thermal()},ensure_ascii=False,indent=2))
        print(f'CHECK OK · pi_team_benchmark {VERSION} · 기본 실행: 전체 영상 공통 평가')
        return 0
    folder = Path(args.resume).resolve() if args.resume else Path(args.out).resolve()/('evaluation_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    if not args.resume:
        folder.mkdir(parents=True)
    with RunLock(folder):
        settings = None
        if args.resume:
            settings = json.loads((folder/'settings.json').read_text())
            if settings.get('protocol_version') != 'team-video-3.0':
                raise ValueError('이전 36장 시험을 버전 3 전체 평가에 합치지 않습니다. 새 전체 시험을 실행하세요.')
        rows = recover_rows(folder/'predictions.jsonl')
        sessions,model_info = [],{}
        if (folder/'metadata.json').exists():
            metadata = json.loads((folder/'metadata.json').read_text())
            sessions,model_info = metadata.get('sessions',[]),metadata.get('model',{})
            for session in sessions:
                if session.get('status') == 'running':
                    session['status'],session['end_index'] = 'unclosed',len(rows)
        if settings:
            if digest(settings) != settings['signature']:
                raise ValueError('저장된 설정 무결성 확인 실패')
            validate_rows(rows,settings)
        if args.save_only or settings and len(rows) == len(settings['plan']):
            status = 'complete' if len(rows) == len(settings['plan']) else 'interrupted'
            _,archive = save_results(folder,settings,rows,status,sessions,model_info)
            print(f'상태: {status} | 보고서: {folder/"report.md"} | ZIP: {archive}')
            return 0
        import cv2,torch
        from ultralytics import YOLO
        if settings:
            check_resume_files(settings)
        else:
            config = validate_config(json.loads(Path(args.config).read_text()))
            if args.input_mode:
                config['input_mode'] = args.input_mode
            source,weights = Path(args.source).resolve(),Path(args.weights).resolve()
            if not source.is_file() or not weights.is_file():
                raise ValueError('로컬 영상 또는 가중치 파일이 없습니다')
            if args.threads is not None and args.threads < 1:
                raise ValueError('스레드 수는 1 이상이어야 합니다')
            video = source_info(source,cv2)
            source_hash = sha256(source)
            ref = config['reference']
            ref_ok = source_hash == ref['source_sha256'] and [video['width'],video['height']] == ref['frame_size']
            if not ref_ok:
                print('다른 영상이므로 위치·인원·구간 참조 채점을 생략합니다.',flush=True)
            plan = make_plan(video,config,ref_ok)
            print(f"pi_team_benchmark {VERSION} | 전체 평가 준비 | 전체 영상 {sum('timeline' in p['roles'] for p in plan)}장 | 고유 추론 {len(plan)}장 | 입력 {config['imgsz']}",flush=True)
            prepare_start = time.perf_counter()
            if config['input_mode'] == 'jpeg':
                prepare_jpegs(source,plan,folder,cv2)
            settings = {'protocol_version':'team-video-3.0','program_version':VERSION,'reference_commit':COMMIT,
                'config':config,'source':str(source),'source_sha256':source_hash,'weights':str(weights),'weights_sha256':sha256(weights),
                'video':video,'reference_ok':ref_ok,'plan':plan,'device':args.device,'threads':args.threads,
                'expected_model_yaml':args.expected_model_yaml,'model_label':args.label,
                'hardware':hardware(),'packages':package_versions(),'preparation_s':time.perf_counter()-prepare_start,
                'code_sha256':{n:sha256(ROOT/n) for n in ('pi_team_benchmark.py','benchmark_common.py','evaluation.py')}}
            settings['signature'] = digest(settings)
            atomic_json(folder/'settings.json',settings)
        config = settings['config']
        def stop(*_):
            global STOP
            STOP = True
        def snapshot(*_):
            global SNAPSHOT
            SNAPSHOT = True
        for sig in (signal.SIGINT,signal.SIGTERM):
            signal.signal(sig,stop)
        if hasattr(signal,'SIGUSR1'):
            signal.signal(signal.SIGUSR1,snapshot)
        pid = folder/'pid.txt'
        pid.write_text(str(os.getpid()))
        start = time.perf_counter()
        session = {'status':'running','started_at':datetime.now().astimezone().isoformat(),
            'start_index':len(rows),'thermal_start':thermal(),'warmup_ms':[],'model_load_s':None}
        sessions.append(session)
        atomic_json(folder/'metadata.json',{'settings':settings,'sessions':sessions,'model':model_info})
        error,status = None,'interrupted'
        previous_count = len(rows)
        generator = None
        try:
            load_start = time.perf_counter()
            model = YOLO(settings['weights'])
            session['model_load_s'] = time.perf_counter()-load_start
            yaml_name = Path(str(getattr(model.model,'yaml',{}).get('yaml_file',''))).name
            if yaml_name != settings['expected_model_yaml']:
                raise ValueError(f"모델 불일치: 실제 {yaml_name}, 요청 {settings['expected_model_yaml']}")
            parameters = sum(p.numel() for p in model.model.parameters()) if hasattr(model.model,'parameters') else None
            label = settings.get('model_label') or Path(yaml_name).stem.replace('yolo','YOLO',1)+' v2'
            model_info = {'label':label,'yaml_file':yaml_name,'parameters':parameters}
            kwargs = {'imgsz':config['imgsz'],'conf':config['predict_confidence'],'classes':[0,60],
                      'device':settings['device'],'verbose':False}
            remaining = settings['plan'][previous_count:]
            generator = ((p,p['jpeg_path'],0.) for p in remaining) if config['input_mode']=='jpeg' else read_targets(settings['source'],remaining,cv2)
            print(f"pi_team_benchmark {VERSION} | 전체 평가 | {label} | {settings['device']} | 재개 {previous_count}/{len(settings['plan'])} | output={folder}",flush=True)
            with open(folder/'predictions.jsonl','ab') as raw:
                for p,source,decode_ms in generator:
                    if STOP:
                        break
                    if p['index'] == previous_count:
                        for _ in range(config['warmup_runs']):
                            synchronize(torch,settings['device'])
                            w0 = time.perf_counter()
                            model.predict(source,imgsz=config['imgsz'],device=settings['device'],verbose=False)
                            synchronize(torch,settings['device'])
                            session['warmup_ms'].append((time.perf_counter()-w0)*1000)
                        if settings['threads'] is not None:
                            torch.set_num_threads(settings['threads'])
                        session['torch_threads_during_inference'] = torch.get_num_threads()
                        session['predictor_rect'] = getattr(getattr(model,'predictor',None),'args',None).rect if getattr(model,'predictor',None) else None
                        atomic_json(folder/'metadata.json',{'settings':settings,'sessions':sessions,'model':model_info})
                    pipeline_start = time.perf_counter()
                    synchronize(torch,settings['device'])
                    t0 = time.perf_counter()
                    result = model.predict(source,**kwargs)[0]
                    synchronize(torch,settings['device'])
                    predict_ms = (time.perf_counter()-t0)*1000
                    detections = [{'class_id':int(b.cls),'xyxy':b.xyxy[0].tolist(),'confidence':float(b.conf)} for b in result.boxes]
                    confidence = zone_conf(detections,config['reference']['zone_points']) if settings['reference_ok'] else None
                    pipeline_ms = decode_ms+(time.perf_counter()-pipeline_start)*1000
                    resource = thermal() if 'timeline' in p['roles'] else {'temperature_c':None,'throttled':None}
                    row = {'index':p['index'],'frame_index':p['frame_index'],'time_s':p['time_s'],'roles':p['roles'],
                        'signature':settings['signature'],'predict_ms':predict_ms,'model_inference_ms':result.speed.get('inference'),
                        'pipeline_ms':pipeline_ms,'decode_ms':decode_ms,'detections':detections,'confidence':confidence,
                        'peak_rss_mib':peak_rss_mb(),'temperature_c':resource['temperature_c'],'throttled':resource['throttled']}
                    raw.write((json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n').encode())
                    raw.flush()
                    os.fsync(raw.fileno())
                    rows.append(row)
                    atomic_json(folder/'checkpoint.json',{'samples':len(rows),'next_index':len(rows),'last_frame_index':p['frame_index'],
                                'signature':settings['signature'],'session_elapsed_s':time.perf_counter()-start})
                    mean = sum(r['predict_ms'] for r in rows[-30:])/min(len(rows),30)
                    eta = (len(settings['plan'])-len(rows))*mean/60000
                    print(f"[{len(rows)}/{len(settings['plan'])}] t={p['time_s']:.2f}s | predict={predict_ms:.0f}ms | {'/'.join(p['roles'])} | 남은 시간 약 {eta:.1f}분",flush=True)
                    if SNAPSHOT:
                        save_results(folder,settings,rows,'running',sessions,model_info)
                        SNAPSHOT = False
                if len(rows) == len(settings['plan']):
                    status = 'complete'
        except Exception as e:
            error,status = f'{type(e).__name__}: {e}','error'
        finally:
            if generator is not None and hasattr(generator,'close'):
                generator.close()
            session.update({'status':status,'ended_at':datetime.now().astimezone().isoformat(),'end_index':len(rows),
                'wall_s':time.perf_counter()-start,'thermal_end':thermal()})
            _,archive = save_results(folder,settings,rows,status,sessions,model_info,error)
            pid.unlink(missing_ok=True)
        print(f'상태: {status} | 보고서: {folder/"report.md"} | ZIP: {archive}',flush=True)
        if error:
            print(error,file=sys.stderr)
        return 1 if error else 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError,OSError,RuntimeError) as e:
        print(f'ERROR: {e}',file=sys.stderr)
        raise SystemExit(1)
