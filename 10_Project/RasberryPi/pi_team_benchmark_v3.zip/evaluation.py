"""Deterministic team-video sampling, scenario scoring and compact report output."""
import html
import json
import math
import re
from collections import Counter
from pathlib import Path

from benchmark_common import atomic_json, stats, state_step


def validate_config(c):
    if c['protocol_version'] != 'team-video-3.0':
        raise ValueError('지원하지 않는 공통 평가 규약입니다')
    if c['input_mode'] not in ('jpeg', 'video') or c['imgsz'] != 960:
        raise ValueError('팀 기준은 입력 960, jpeg 또는 video입니다')
    if c['timeline_interval_s'] <= 0 or not 0 < c['holdout_fraction'] < 1:
        raise ValueError('표본 간격 또는 미학습 구간 비율을 확인하세요')
    if c['warmup_runs'] < 1 or c['confirm'] < 1:
        raise ValueError('워밍업/연속 확인 횟수는 1 이상이어야 합니다')
    if not 0 <= c['predict_confidence'] <= min(c['person_confidence'], c['table_confidence'], c['occupancy_confidence']) <= 1:
        raise ValueError('수집 신뢰도는 채점 임계값보다 높을 수 없습니다')
    if c['prone_last_seconds'] < 0 or c['target_interval_s'] <= 0 or c['absence_limit_s'] <= 0:
        raise ValueError('시간 기준을 확인하세요')
    return c


def make_plan(video, c, reference_ok):
    """CFR frame indices: keep the timeline independent of auxiliary samples."""
    fps, n = video['fps'], video['frame_count']
    if fps <= 0 or n <= 0:
        raise ValueError('유효한 CFR 동영상이 필요합니다')
    duration = n / fps
    roles = {}
    def add(frame, role):
        if 0 <= frame < n:
            roles.setdefault(frame, set()).add(role)
    k = 0
    while k * c['timeline_interval_s'] < duration - 1e-9:
        f = round(k * c['timeline_interval_s'] * fps)
        add(f, 'timeline')
        if f / fps >= duration * (1 - c['holdout_fraction']):
            add(f, 'table_holdout')
        k += 1
    if reference_ok:
        start = max(0, math.ceil(n - c['prone_last_seconds'] * fps - 1e-9))
        for f in range(start, n): add(f, 'prone')
        ref = c['reference']
        a, b = ref['people_window_s']
        k = 0
        while a + k * ref['people_interval_s'] < b - 1e-9:
            add(round((a + k * ref['people_interval_s']) * fps), 'people')
            k += 1
    return [{'index': i, 'frame_index': f, 'time_s': f/fps, 'roles': sorted(roles[f])}
            for i, f in enumerate(sorted(roles))]


def point_in_polygon(x, y, points):
    inside = False
    for i, (x1, y1) in enumerate(points):
        x2, y2 = points[(i+1) % len(points)]
        cross = (x-x1)*(y2-y1) - (y-y1)*(x2-x1)
        if abs(cross) <= 1e-7 and min(x1,x2)-1e-7 <= x <= max(x1,x2)+1e-7 and min(y1,y2)-1e-7 <= y <= max(y1,y2)+1e-7:
            return True
        if (y1 > y) != (y2 > y) and x < (x2-x1)*(y-y1)/(y2-y1)+x1:
            inside = not inside
    return inside


def center_in_box(box, roi):
    x, y = (box[0]+box[2])/2, (box[1]+box[3])/2
    return roi[0] <= x <= roi[2] and roi[1] <= y <= roi[3]


def zone_conf(detections, points):
    return max((d['confidence'] for d in detections if d['class_id'] == 0 and
                point_in_polygon((d['xyxy'][0]+d['xyxy'][2])/2,
                                 (d['xyxy'][1]+d['xyxy'][3])/2, points)), default=0.)


def iou(a, b):
    intersection = max(0,min(a[2],b[2])-max(a[0],b[0])) * max(0,min(a[3],b[3])-max(a[1],b[1]))
    union = max(0,a[2]-a[0])*max(0,a[3]-a[1]) + max(0,b[2]-b[0])*max(0,b[3]-b[1]) - intersection
    return intersection/union if union > 0 else 0.


def matched_people(detections, rois, threshold):
    """Maximum one-to-one center/ROI matching; duplicates cannot inflate counts."""
    candidates = [d for d in detections if d['class_id'] == 0 and d['confidence'] >= threshold]
    assigned = {}
    def assign(det_index, seen):
        for roi_index, roi in enumerate(rois):
            if roi_index in seen or not center_in_box(candidates[det_index]['xyxy'], roi): continue
            seen.add(roi_index)
            if roi_index not in assigned or assign(assigned[roi_index], seen):
                assigned[roi_index] = det_index
                return True
        return False
    for j in range(len(candidates)): assign(j, set())
    return len(assigned)


def truth_at(t, ref):
    t = round(t, 6)
    if any(a <= t <= b for a,b in ref['absence_intervals_s']): return False
    if any(a <= t <= b for a,b in ref['presence_intervals_s']): return True
    return None


def counters(rows, c):
    timeline = []
    streak, last_seen, absent_since = 0, None, None
    for r in rows:
        if 'timeline' not in r['roles']: continue
        t, confidence = r['time_s'], zone_conf(r['detections'], c['reference']['zone_points'])
        present = confidence >= c['occupancy_confidence']
        streak, last_seen, state = state_step(streak,last_seen,t,confidence,c['occupancy_confidence'],c['confirm'],c['absence_limit_s'])
        absent_since = None if present else t if absent_since is None else absent_since
        timeline.append({'frame_index':r['frame_index'],'time_s':t,'confidence':confidence,'present':present,
                         'state':state,'streak':streak,'last_seen_s':last_seen,
                         'team_absence_s':t-last_seen,'continuous_absence_s':0 if absent_since is None else t-absent_since})
    return timeline


def analyse(rows, settings):
    c, ref_ok = settings['config'], settings['reference_ok']
    timeline_rows = [r for r in rows if 'timeline' in r['roles']]
    table_rows = [r for r in rows if 'table_holdout' in r['roles']]
    prone_rows = [r for r in rows if 'prone' in r['roles']]
    people_rows = [r for r in rows if 'people' in r['roles']]
    sizes = {role:sum(role in p['roles'] for p in settings['plan']) for role in ('timeline','table_holdout','prone','people')}
    timing = {}
    for group, selected in [('whole_video',timeline_rows),('holdout',table_rows),('all_unique',rows),('prone',prone_rows)]:
        timing[group] = {k:stats([r.get(k) for r in selected]) for k in ('predict_ms','model_inference_ms','pipeline_ms')}
    n_t = len(timeline_rows)
    mean = timing['whole_video']['predict_ms']['mean']
    speed = {'serial_fps':1000/mean if mean else None,
             'over_target':sum(r['predict_ms'] > c['target_interval_s']*1000 for r in timeline_rows),
             'samples':n_t,'peak_rss_mib':max((r['peak_rss_mib'] for r in rows if r.get('peak_rss_mib') is not None),default=None),
             'sampled_temperature_c':stats([r.get('temperature_c') for r in rows])}
    table = {'available':ref_ok,'success':0,'n':len(table_rows),'expected':sizes['table_holdout'],'reference':'provisional visual box',
             'detection_persistence':sum(any(d['class_id']==60 and d['confidence']>=c['table_confidence'] for d in r['detections']) for r in table_rows)}
    if ref_ok:
        for r in table_rows:
            ds=[d for d in r['detections'] if d['class_id']==60 and d['confidence']>=c['table_confidence']]
            candidate=max(ds,key=lambda d:d['confidence']) if ds else None
            table['success'] += bool(candidate and iou(candidate['xyxy'],c['reference']['table_xyxy'])>=c['reference']['table_iou_threshold'])
    prone={'available':ref_ok,'success':0,'n':len(prone_rows),'expected':sizes['prone'],'reference':'provisional target-person ROI'}
    people={'available':ref_ok,'success':0,'n':len(people_rows)*len(c['reference']['people_rois_xyxy']),
            'frames':len(people_rows),'expected_frames':sizes['people'],'reference':'provisional three-person window and ROIs'}
    if ref_ok:
        for r in prone_rows:
            prone['success'] += any(d['class_id']==0 and d['confidence']>=c['person_confidence'] and
                                    center_in_box(d['xyxy'],c['reference']['prone_roi_xyxy']) for d in r['detections'])
        people['success']=sum(matched_people(r['detections'],c['reference']['people_rois_xyxy'],c['person_confidence']) for r in people_rows)
    timeline=counters(rows,c) if ref_ok else []
    present=[r for r in timeline if truth_at(r['time_s'],c['reference']) is True]
    absent=[r for r in timeline if truth_at(r['time_s'],c['reference']) is False]
    present_conf=[r['confidence'] for r in present]
    holdout_conf=[r['confidence'] for r in present if r['time_s']>=settings['video']['duration_s']*(1-c['holdout_fraction'])]
    occupancy={'available':ref_ok,'present_samples':len(present),'absent_samples':len(absent),
        'missed_presence':sum(not r['present'] for r in present),'false_presence':sum(r['present'] for r in absent),
        'states':dict(Counter(r['state'] for r in timeline)),
        'minimum_conf_when_present':min(present_conf,default=None),
        'holdout_present_conf':{'min':min(holdout_conf,default=None),'mean':sum(holdout_conf)/len(holdout_conf) if holdout_conf else None},
        'absence_windows':[],'transitions':[]}
    prev = None
    for r in timeline:
        if r['state'] != prev:
            occupancy['transitions'].append({'time_s':r['time_s'],'from':prev,'to':r['state']})
            prev=r['state']
    for start,end in c['reference']['absence_intervals_s'] if ref_ok else []:
        margin=c['reference']['absence_evaluation_margin_s']
        inner=[r for r in timeline if start+margin<=r['time_s']<end-margin]
        if not inner: continue
        expected_streak=inner[-1]['time_s']-inner[0]['time_s']
        longest=0.;begin=None
        for r in inner:
            begin=None if r['present'] else r['time_s'] if begin is None else begin
            if begin is not None:longest=max(longest,r['time_s']-begin)
        resets=sum(r['streak']>=c['confirm'] for r in inner)
        after=[r for r in timeline if end<r['time_s']<=end+30]
        first_detected=next((r['time_s'] for r in after if r['present']),None)
        first_red=next((r['time_s'] for r in after if r['state']=='red'),None)
        occupancy['absence_windows'].append({'recorded_start_s':start,'recorded_end_s':end,'observed_to_s':inner[-1]['time_s'],
            'scored_samples':len(inner),'reference_continuous_span_s':expected_streak,
            'longest_continuous_absence_s':longest,'continuous_span_error_s':longest-expected_streak,
            'false_timer_refresh_samples':resets,'first_presence_after_end_s':first_detected,'first_red_after_end_s':first_red})
    return {'timing':timing,'speed':speed,'sample_counts':{'processed_unique':len(rows),'planned_unique':len(settings['plan']),
            'actual':{role:sum(role in r['roles'] for r in rows) for role in sizes},'planned':sizes},
            'table':table,'prone':prone,'people':people,'occupancy':occupancy,'timeline':timeline,
            'object_map':None}


def table_md(headers, rows):
    def cell(x):return str(x).replace('|','/').replace('\n',' ')
    return '\n'.join(['| '+' | '.join(map(cell,headers))+' |', '| '+' | '.join(['---']*len(headers))+' |']+
                     ['| '+' | '.join(map(cell,r))+' |' for r in rows])


def result_tables(summary, settings):
    a,c=summary['analysis'],settings['config']
    name=summary.get('model',{}).get('label') or settings.get('model_label') or 'YOLO26s v2'
    def f(x,d=1):return '미측정' if x is None else f'{x:,.{d}f}'
    def pct(x):
        if not x['available']:return '미평가'
        if not x['n']:return '미측정'
        return f"{x['success']/x['n']*100:.1f}% ({x['success']}/{x['n']})*"
    t=a['timing']['whole_video']['predict_ms']
    stage=a['timing']['whole_video']['model_inference_ms']
    pipeline=a['timing']['whole_video']['pipeline_ms']
    speed=table_md(['모델','장치','표본','평균 ms/장','P95 ms/장','최대 ms/장','환산 장/초','최대 메모리 MiB','최고 관측 온도 °C'],
        [[name,settings['device'],t['n'],f(t['mean']),f(t['p95']),f(t['max']),f(a['speed']['serial_fps'],3),f(a['speed']['peak_rss_mib']),f(a['speed']['sampled_temperature_c']['max'])]])
    scopes=table_md(['측정 범위','평균 ms/장','P95 ms/장','최대 ms/장'],[
        ['모델 내부 추론',f(stage['mean']),f(stage['p95']),f(stage['max'])],
        ['predict 전체 (주 지표)',f(t['mean']),f(t['p95']),f(t['max'])],
        ['입력 읽기·predict·박스 추출',f(pipeline['mean']),f(pipeline['p95']),f(pipeline['max'])]])
    params=summary.get('model',{}).get('parameters')
    detection=table_md(['모델','테이블 (뒤 20%)','엎드린 사람','앉은 사람 (재구성 구간)','파라미터','CPU 1장당'],
        [[name,pct(a['table']),pct(a['prone']),pct(a['people']),f(params/1e6,2)+'M' if params else '미측정',f(t['mean'])+'ms' if settings['device']=='cpu' else '별도 장치']])
    o=a['occupancy']
    state=table_md(['모델','빨강','노랑','초록','사람 있을 때 최저 신뢰도','미학습 구간 최저 / 평균','놓침 / 오탐'],
        [[name,*[o['states'].get(s,0) if o['available'] else '미평가' for s in ('red','yellow','green')],
          f(o['minimum_conf_when_present'],3),f(o['holdout_present_conf']['min'],3)+' / '+f(o['holdout_present_conf']['mean'],3),
          f"{o['missed_presence']} / {o['false_presence']}" if o['available'] else '미평가']])
    window=table_md(['정답 부재 구간','관측 구간 길이 s','최장 연속 부재 s','연속 길이 오차 s','오검출 타이머 갱신 표본'],[
        [f"{w['recorded_start_s']:.0f}~{w['recorded_end_s']:.0f}s",f(w['reference_continuous_span_s']),f(w['longest_continuous_absence_s']),
         f(w['continuous_span_error_s']),w['false_timer_refresh_samples']] for w in o['absence_windows']]) if o['absence_windows'] else '미측정'
    return speed,scopes,detection,state,window


def write_reports(folder, summary, settings):
    a,c=summary['analysis'],settings['config']
    speed,scopes,detection,state,window=result_tables(summary,settings)
    model=summary.get('model',{}).get('label') or settings.get('model_label','YOLO26s v2')
    n=a['sample_counts']
    partial=summary['status']!='complete'
    warnings=[]
    if partial:warnings.append('부분 결과: 끝나지 않은 구간의 성공률을 전체 평가 결과로 해석하지 않는다.')
    if not settings['reference_ok']:warnings.append('등록된 참조 영상과 달라 위치·인원·구간 정답 채점을 적용하지 않았다.')
    if len(summary.get('sessions',[]))>1:warnings.append('중단 후 재개한 분할 실행이다. 연속 가동 시험으로 해석하지 않는다.')
    md=f'''# 라즈베리파이 성능 평가

상태: **{summary['status']}** · 모델: **{model}** · 장치: **{settings['hardware'].get('board') or settings['hardware']['machine']} / {settings['device']}**

## 1. 시험 조건

- 입력 영상: {Path(settings['source']).name}, {settings['video']['width']}×{settings['video']['height']}, {settings['video']['fps']:g} FPS.
- 입력 크기 {c['imgsz']}, {c['input_mode']} 입력, 검출 수집 {c['predict_confidence']}, 사람 {c['person_confidence']}, 테이블 {c['table_confidence']}, 재실 {c['occupancy_confidence']}.
- 전체 영상 {c['timeline_interval_s']:g}초 간격: {n['actual']['timeline']}/{n['planned']['timeline']}장. 테이블 미학습 뒤 20%: {n['actual']['table_holdout']}/{n['planned']['table_holdout']}장.
- 엎드림: 마지막 {c['prone_last_seconds']:g}초 {n['actual']['prone']}/{n['planned']['prone']}장. 앉은 사람: 재구성 구간 {n['actual']['people']}/{n['planned']['people']}장.
- 워밍업 {c['warmup_runs']}회 제외. 중복 프레임은 한 번만 추론: {n['processed_unique']}/{n['planned_unique']}장.

## 2. 처리속도

{speed}

{scopes}

팀 검증 표본 간격({c['target_interval_s']:g}초)보다 처리시간이 긴 표본: **{a['speed']['over_target']}/{a['speed']['samples']}장**. 환산 처리량은 predict 평균의 역수이며 카메라 동시 수신 성능이 아니다. 모델 로딩·표본 준비·워밍업·결과 저장은 주 지표에서 제외한다.

## 3. 탐지 결과

{detection}

* 테이블은 최고 신뢰도 박스와 참조 박스의 IoU≥{c['reference']['table_iou_threshold']}로 채점한다. 엎드림은 지정 대상 ROI의 사람 신뢰도≥{c['person_confidence']}, 앉은 사람은 세 참조 영역의 일대일 검출 수로 센다. 중복 박스로 인원을 부풀리지 않는다.

**추정 기준:** 원본 evaluate.py/정답 라벨이 없어, 제공 영상을 직접 확인한 임시 참조 박스·영역을 사용했다. 앉은 사람 구간은 {c['reference']['people_window_s'][0]}~{c['reference']['people_window_s'][1]}초, {c['reference']['people_interval_s']:g}초 간격으로 재구성했다. * 표시는 원래 팀 라벨로 계산한 정확도나 mAP가 아닌 참조 시나리오 점수다.

## 4. 재실·연속 부재

{state}

{window}

다각형 영역 안 사람 박스 중심으로 판정한다. 신호등은 팀 server.py의 연속 {c['confirm']}회 확인·{c['absence_limit_s']/60:g}분 기준을 따른다. 연속 부재는 검출 유무 기준으로 별도 집계하며, 부재 경계 양쪽 {c['reference']['absence_evaluation_margin_s']:g}초를 제외한다. 영상 시각으로 계산하므로 느린 추론시간이나 재개 대기시간을 부재시간에 더하지 않는다.

## 5. 해석 범위

전체 재실 시험에는 학습에 사용된 앞 80%가 포함된다. 뒤 20%의 속도·테이블 평가는 summary.json에 별도 저장한다. 한 방의 한 영상 시험이며 30분 연속 부재·여러 카메라 동시 운용·SAM 초기화/통신 성능은 이 결과로 확정하지 않는다.
'''
    if warnings:md+='\n'+'\n'.join('- '+w for w in warnings)+'\n'
    (folder/'report.md').write_text(md,encoding='utf-8')
    # Only render the known Markdown subset; no embedded JSON metadata dump.
    def inline(text):
        return re.sub(r'\*\*(.+?)\*\*',r'<strong>\1</strong>',html.escape(text))
    lines=md.splitlines();parts=[];i=0
    while i<len(lines):
        line=lines[i]
        if line.startswith('| '):
            block=[]
            while i<len(lines) and lines[i].startswith('| '):block.append(lines[i]);i+=1
            cells=lambda s:[inline(x.strip()) for x in s.strip().strip('|').split('|')]
            parts.append('<table><thead><tr>'+''.join('<th>'+x+'</th>' for x in cells(block[0]))+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+x+'</td>' for x in cells(r))+'</tr>' for r in block[2:])+'</tbody></table>')
            continue
        if line.startswith('#'):
            level=len(line)-len(line.lstrip('#'));parts.append(f'<h{level}>'+inline(line[level:].strip())+f'</h{level}>')
        elif line.strip():parts.append('<p>'+inline(line)+'</p>')
        i+=1
    body='<!doctype html><html lang="ko"><meta charset="utf-8"><title>라즈베리파이 성능 평가</title><style>body{font:16px/1.65 system-ui,sans-serif;max-width:1260px;margin:36px auto;padding:0 24px;color:#1e302e}h1{font-size:28px}h2{margin-top:30px;font-size:21px}table{border-collapse:collapse;width:100%;font-size:14px;margin:16px 0}th,td{padding:9px;border:1px solid #ddd;text-align:left}th{background:#f1f4f2}p{overflow-wrap:anywhere}h1+p{color:#42675d}</style>'+''.join(parts)+'</html>'
    (folder/'report.html').write_text(body,encoding='utf-8')
