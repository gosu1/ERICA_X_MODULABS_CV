#!/usr/bin/env python3
"""Pinned team-reference benchmark. No package installation or remote inference."""
import argparse
import csv
import hashlib
import html
import importlib.metadata
import json
import math
import os
import platform
import signal
import statistics
import subprocess
import sys
import time
import zipfile
from collections import Counter
from datetime import datetime
from pathlib import Path

VERSION = "3.0"
ROOT = Path(__file__).resolve().parent
COMMIT = "a0b659ee95e1e287437450f6c1f51a566662da6b"
WEIGHT_SHA256 = "cb5399aba278bdcc74cfb6f48a0039f7fc90389fc751621b31c7ea956dbb1c09"
STOP = False


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, obj):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    if os.name == "posix":
        fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


class RunLock:
    def __init__(self, folder):
        self.path = folder / "run.lock"

    def __enter__(self):
        self.f = open(self.path, "a+b")
        try:
            if os.name == "posix":
                import fcntl
                fcntl.flock(self.f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            else:
                import msvcrt
                if self.f.seek(0, 2) == 0:
                    self.f.write(b"0")
                    self.f.flush()
                self.f.seek(0)
                msvcrt.locking(self.f.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            self.f.close()
            raise RuntimeError("같은 결과 폴더의 시험이 실행 중입니다")
        return self

    def __exit__(self, *exc):
        self.f.close()


def recover_rows(path):
    """Only a torn final line is recoverable; never ignore interior corruption."""
    if not path.exists():
        return []
    rows, offset = [], 0
    with open(path, "rb+") as f:
        while True:
            start = f.tell()
            line = f.readline()
            if not line:
                break
            if not line.endswith(b"\n"):
                tail = path.with_name("discarded_tail_" + str(time.time_ns()) + ".bin")
                tail.write_bytes(line)
                f.seek(start)
                f.truncate()
                f.flush()
                os.fsync(f.fileno())
                break
            try:
                row = json.loads(line)
            except (ValueError, UnicodeDecodeError) as e:
                raise ValueError(f"원시 기록 내부 손상: {start} bytes") from e
            if row.get("index") != len(rows):
                raise ValueError("원시 기록의 표본 번호가 연속되지 않습니다")
            rows.append(row)
            offset = f.tell()
    return rows


def stats(values):
    values = sorted(float(x) for x in values if x is not None)
    if not values:
        return {"n": 0, "mean": None, "p95": None, "max": None}
    pos = (len(values) - 1) * .95
    lo, hi = math.floor(pos), math.ceil(pos)
    return {"n": len(values), "mean": statistics.mean(values),
            "p95": values[lo] + (values[hi] - values[lo]) * (pos - lo), "max": values[-1]}


def state_step(streak, last_seen, t, confidence, threshold=.30, confirm=2, limit_s=1800):
    # Same transitions and initial state as pinned server.py. No debounce added.
    streak = streak + 1 if confidence >= threshold else 0
    if streak >= confirm or last_seen is None:
        last_seen = t
    color = "red" if streak >= confirm else "yellow" if t - last_seen < limit_s else "green"
    return streak, last_seen, color


def known_presence(t, matched_source):
    if not matched_source:
        return None
    t = round(t, 6)
    # EXPeriments' hand-reviewed 2-second grid; gaps remain unlabeled.
    if 212 <= t <= 1146:
        return False
    if 0 <= t <= 210 or 1148 <= t <= 1317.833334:
        return True
    return None


def package_versions():
    result = {}
    for name in ("ultralytics", "torch", "torchvision", "opencv-python", "opencv-python-headless", "numpy"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = None
    return result


def read_text(path):
    try:
        return Path(path).read_text().strip().strip("\0")
    except OSError:
        return None


def hardware():
    return {"board": read_text("/proc/device-tree/model"), "machine": platform.machine(),
            "platform": platform.platform(), "python": platform.python_version(), "cpus": os.cpu_count()}


def thermal():
    temp = read_text("/sys/class/thermal/thermal_zone0/temp")
    try:
        flags = subprocess.run(["vcgencmd", "get_throttled"], text=True, capture_output=True,
                               timeout=2).stdout.strip() or None
    except (OSError, subprocess.TimeoutExpired):
        flags = None
    return {"temperature_c": float(temp) / 1000 if temp else None, "throttled": flags}


def peak_rss_mb():
    try:
        import resource
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (2**20 if sys.platform == "darwin" else 1024)
    except ImportError:
        return None


def synchronize(torch, device):
    if str(device).startswith("mps"):
        torch.mps.synchronize()
    elif str(device) != "cpu" and torch.cuda.is_available():
        torch.cuda.synchronize()


