# 라즈베리파이 공통 영상 평가 프로그램 v3

팀의 GitHub 실험 기록과 모델 설명서를 바탕으로 전체 영상 평가를 실행한다. 처리속도가 주 지표이며 탐지·재실·연속 부재 결과를 같은 실행에서 기록한다. 기본 모델은 동봉된 YOLO26s v2, 입력 크기는 960이다.

## 실행

다운로드한 ZIP을 다운로드 폴더에 `pi_team_benchmark_v3.zip`으로 저장하고 **Windows PowerShell**에서 전송한다. 아래 IP는 이번에 확인한 주소이며, 바뀌면 현재 Pi 주소로 교체한다.

```powershell
scp "$env:USERPROFILE\Downloads\pi_team_benchmark_v3.zip" phc_11@192.168.0.9:~/vision/
ssh phc_11@192.168.0.9 "mkdir -p ~/vision/benchmark_team_v3 && unzip -o ~/vision/pi_team_benchmark_v3.zip -d ~/vision/benchmark_team_v3"
```

기존 v2 폴더와 구분하여 `benchmark_team_v3`에 설치한다. 같은 Pi에서 다른 시험이 실행 중이면 먼저 종료하고 새 시험을 시작한다. 프로그램과 설정 파일을 함께 업데이트해야 한다.

**라즈베리파이 터미널**에서:

```bash
cd ~/vision/benchmark_team_v3
python3 pi_team_benchmark.py --version
python3 pi_team_benchmark.py --check
python3 -u pi_team_benchmark.py --source ../benchmark/test.mp4
```

버전 확인 결과는 `pi_team_benchmark 3.0 | protocol=team-video-3.0`이다. `--version`은 모델·영상·추론 패키지를 읽지 않는다. 실행 시작 시 `전체 영상 659장 | 고유 추론 767장`이 표시된다. 이와 다르면 실행 경로와 사용한 파일을 확인한다.

기존 설치 환경을 사용한다. 새 패키지/가상환경 생성과 모델 자동 다운로드는 수행하지 않는다.

## 기본 평가 구성

| 항목 | 표본과 기준 |
|---|---|
| 전체 영상 처리속도·재실 판정 | 2초 간격 659장 |
| 미학습 테이블 평가 | 영상 뒤 20%, 전체 표본 중 131장 |
| 엎드린 사람 | 마지막 7초의 모든 프레임, 84장 |
| 앉은 사람 참고 평가 | 60~78초, 0.5초 간격 36장, 참조 영역 3개 |
| 고유 추론 수 | 겹치는 프레임을 합쳐 총 767장 |

기존 36장 예비 속도 측정값을 대입하면 전체 실행은 **약 35~40분 예상**이다. 발열·부하에 따라 달라질 수 있다. 전체 영상의 659장만으로 주 속도 평균을 계산하므로 엎드림·인원 보조 표본이 평균을 편향시키지 않는다. 보조 표본은 신호등의 연속 확인 횟수와 부재 카운터에도 개입하지 않는다.

동일 영상에서 같은 프레임 인덱스를 선택하고 JPEG로 저장해 경로를 predict에 전달한다. 기본 호출은 `imgsz=960, conf=0.25, classes=[0,60], device=cpu`이며 워밍업 1회는 제외한다. rect, iou, max_det 등은 팀 코드처럼 라이브러리 기본값이다. 이 조건을 공통 설정 파일과 함께 팀에서 재사용할 수 있다.

원본 배열 입력으로 팀 server.py의 입력 경로를 비교하려면 `--input-mode video`를 사용한다. 인위적인 JPEG 변환이 없는 별도 프로필이므로 기본 JPEG 결과와 구분해 기록한다. 두 입력 모드 모두 처리속도·탐지 조건을 고정해서 비교해야 한다.

## 결과

각 실행은 새 `results_team/evaluation_날짜_시각/` 폴더와 같은 이름의 ZIP을 만든다.

| 파일 | 내용 |
|---|---|
| `report.md` | GitHub 형식의 핵심 조건, 처리시간 비교 표, 탐지 표, 색 판정·연속 부재 표 |
| `report.html` | 같은 표를 브라우저에서 읽을 수 있는 버전 |
| `results.csv` | 프레임별 처리시간·자원 측정값 |
| `timeline.csv` | 전체 영상 표본의 재실·색·카운터 기록 |
| `predictions.jsonl` | 실제 탐지 박스와 원시 측정값, 표본마다 디스크 동기화 |
| `summary.json` | 수치 분석 결과 |
| `settings.json`, `metadata.json` | 재현·검증용 설정, 해시, 패키지 버전, 실행 이력 |
| `checkpoint.json` | 중단/재개 확인용 저장 지점 |
| `frames/` | 공통 평가 JPEG 캐시; 결과 ZIP에는 포함하지 않음 |

메타데이터 전체를 보고서 본문에 출력하지 않는다. 본문에는 모델·장치·입력·임계값·표본·워밍업 등 결과 판단에 필요한 조건만 표시한다. 시험 직후 프로그램이 생성하는 결과물이며 이 배포 패키지에는 새 실측 결과가 들어 있지 않다.

Windows 바탕화면으로 결과를 받을 때:

```powershell
$Desk = [Environment]::GetFolderPath("Desktop")
scp phc_11@192.168.0.9:~/vision/benchmark_team_v3/results_team/evaluation_*.zip "$Desk"
```

## 기준의 확정 범위와 추정 범위

- 팀 문서에서 확인된 값: 입력 960, 사람 0.35, 테이블 0.25, 테이블 최고 신뢰도 박스의 IoU 0.5, 전체 영상 2초 간격, 미학습 뒤 20%, 마지막 7초 84프레임, 재실 임계값 0.30/연속 2회 확인.
- `evaluate.py`가 없어 추정한 값: 워밍업 1회, 예측 호출/프레임 선택의 통합 방식, 원본 배열 대신 JPEG를 기본으로 선택한 입력 방식.
- **임시 참조**: 영상의 첫 프레임·빈 책상·엎드림 구간을 직접 확인해 책상 박스와 대상 사람 영역을 정했다. 인원 비교는 60~78초로 재구성했다. 팀이 원래 사용한 정답 라벨은 아니므로 관련 백분율에는 `*`를 붙이고 참조 시나리오 점수라고 명시한다. mAP로 부르지 않는다.
- 영상 앞 80%는 학습에 포함되어 전체 재실 평가는 동작 시험이다. 실제 방 상태에 대한 별도 재실/부재 기록을 사용하고 미학습 구간은 따로 집계한다.
- 위치와 구간 참조는 등록된 원본 영상 SHA-256·해상도가 일치할 때만 적용된다. 다른 영상에는 속도와 검출 지속성만 적용한다.

참조 박스/구간/임계값은 `team_config.json`에서 바꿀 수 있다. 추후 원래 팀 라벨을 받으면 이 파일을 교체해 동일 프로그램으로 새 시험을 실행한다. 진행 중인 시험은 저장된 설정으로만 재개한다.

## Connect 종료 후 실행과 상태 확인

```bash
cd ~/vision/benchmark_team_v3
run_log="team_full_$(date +%Y%m%d_%H%M%S).log"
nohup python3 -u pi_team_benchmark.py --source ../benchmark/test.mp4 > "$run_log" 2>&1 < /dev/null &
tail -f "$run_log"
```

재연결 후:

```bash
cd ~/vision/benchmark_team_v3
tail -n 30 -f "$(ls -t team_full_*.log | head -n 1)"
```

`tail`의 Ctrl+C는 로그 보기만 종료한다. Pi 전원은 유지해야 한다.

## 중단·재개

직접 실행한 프로세스는 Ctrl+C로 중단한다. nohup 시험은 **해당 시험이 실행 중일 때** 실제 출력 폴더의 PID를 사용한다.

```bash
# 경로는 출력된 실제 폴더로 바꾼다.
kill -TERM "$(cat results_team/evaluation_날짜_시각/pid.txt)"

# 저장 지점부터 재개
python3 -u pi_team_benchmark.py --resume results_team/evaluation_날짜_시각

# 종료된 시험의 보고서만 복원
python3 pi_team_benchmark.py --resume results_team/evaluation_날짜_시각 --save-only

# 실행 중인 시험의 현재 결과를 저장하고 계속 추론
kill -USR1 "$(cat results_team/evaluation_날짜_시각/pid.txt)"
```

매 표본을 fsync한 뒤 체크포인트를 원자적으로 갱신한다. 강제 종료 후 정상 로그 다음부터 이어가며 오래된 체크포인트보다 원시 로그를 우선한다. 모델·영상·JPEG·설정·코드·환경이 바뀌면 이어 쓰기를 거부한다. 마지막 미완성 줄은 별도 보존 후 제거하고 내부 손상은 오류로 처리한다. 재개 위치로 영상 앞부분을 읽어 이동하는 비용은 표본 처리시간에서 제외한다.

전원 차단 후 남은 오래된 PID로 신호를 보내지 않는다. 재개할 때마다 워밍업을 다시 제외하고 실제 영상 시각으로 타이머를 복원한다. 이전 v2의 36장 시험은 새 전체 시험과 합치지 않는다.

## 다른 모델·장치와 같은 형식으로 비교

```bash
# 기존 YOLO11s 가중치
python3 pi_team_benchmark.py --weights ../benchmark/best.pt --expected-model-yaml yolo11s.yaml --label "YOLO11s v2" --source ../benchmark/test.mp4
```

같은 설정 파일과 원본 영상으로 실행한다. CPU가 기본이며 다른 장치는 `--device`로 명시한다. CPU 스레드는 기본 라이브러리 정책을 따르고, `--threads 4`처럼 지정하면 워밍업 후 적용하여 실제 추론 시점의 값을 기록한다.

## 개발 검증

실제 OpenCV 디코딩과 모의 YOLO를 사용한 단위·통합 검증을 수행했다. 전체 표본 수, 중복 제거, 원본 server.py 상태 전이 일치, 속도 표본 분리, 참조 채점, 중복 박스 처리, 중단/강제 종료 후 재개, 입력 변경 거부, 보고서 본문 형식을 확인했다. 작성 환경에서 실제 Pi/YOLO 추론을 실행한 것은 아니다.
