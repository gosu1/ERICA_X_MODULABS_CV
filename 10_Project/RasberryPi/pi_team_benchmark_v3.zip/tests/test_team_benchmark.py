import ast
import contextlib
import copy
import io
import json
import os
import signal
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import cv2
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT
sys.path.insert(0,str(PACKAGE))
import pi_team_benchmark as b
import evaluation as e
from benchmark_common import state_step


class Scalar:
    def __init__(self,x):self.x=x
    def __int__(self):return int(self.x)
    def __float__(self):return float(self.x)


class Box:
    def __init__(self,cls,box,c):self.cls,self.xyxy,self.conf=Scalar(cls),np.array([box]),Scalar(c)


THREADS=1
def get_threads():return THREADS
def set_threads(n):
    global THREADS
    THREADS=n
FAKE_TORCH=types.SimpleNamespace(get_num_threads=get_threads,set_num_threads=set_threads,
                                cuda=types.SimpleNamespace(is_available=lambda:False))


class FakeYOLO:
    calls=[]
    stop_at=None
    hard_stop_at=None
    snapshot_at=None
    def __init__(self,path):
        self.model=types.SimpleNamespace(yaml={'yaml_file':'yolo26s.yaml'},parameters=lambda:[])
        self.predictor=types.SimpleNamespace(args=types.SimpleNamespace(rect=True))
        self.ready=False
    def predict(self,source,**kwargs):
        if not self.ready:set_threads(3);self.ready=True
        self.calls.append((source,kwargs))
        if len(self.calls)==self.hard_stop_at:os._exit(75)
        if len(self.calls)==self.stop_at:b.STOP=True
        if len(self.calls)==self.snapshot_at:b.SNAPSHOT=True
        frame=int(Path(source).stem.split('_')[-1]) if isinstance(source,str) else round(float(source.mean())/3)
        people=[] if 24<=frame<=48 else [Box(0,[10,10,70,100],.92),Box(0,[120,10,190,100],.91),Box(0,[80,130,150,235],.93),Box(0,[11,10,70,100],.8)]
        return [types.SimpleNamespace(boxes=people+[Box(60,[0,0,320,240],.9)],speed={'inference':1.25})]


class TeamTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.video=self.root/'video.avi'
        w=cv2.VideoWriter(str(self.video),cv2.VideoWriter_fourcc(*'MJPG'),12.,(320,240))
        for i in range(72):w.write(np.full((240,320,3),i*3,np.uint8))
        w.release()
        self.weights=self.root/'weights.pt';self.weights.write_bytes(b'fake model')
        self.config=json.loads((PACKAGE/'team_config.json').read_text())
        c=self.config;c['timeline_interval_s']=1;c['prone_last_seconds']=1
        c['reference'].update(source_sha256=b.sha256(self.video),frame_size=[320,240],
            table_xyxy=[0,0,320,240],prone_roi_xyxy=[0,0,100,120],people_window_s=[0,2],
            people_rois_xyxy=[[0,0,100,120],[100,0,220,120],[0,120,320,240]],
            presence_intervals_s=[[0,1],[5,6]],absence_intervals_s=[[2,4]],absence_evaluation_margin_s=0,
            zone_points=[[0,0],[320,0],[320,240],[0,240]])
        self.cfg=self.root/'config.json';self.cfg.write_text(json.dumps(c))
        FakeYOLO.calls=[];FakeYOLO.stop_at=None;FakeYOLO.hard_stop_at=None;FakeYOLO.snapshot_at=None
        set_threads(1)

    def tearDown(self):self.temp.cleanup()

    def args(self,extra=()):
        return ['--weights',str(self.weights),'--source',str(self.video),'--config',str(self.cfg),'--out',str(self.root/'out'),*extra]

    def call(self,extra=()):
        with patch.dict(sys.modules,{'torch':FAKE_TORCH,'ultralytics':types.SimpleNamespace(YOLO=FakeYOLO)}):
            with contextlib.redirect_stdout(io.StringIO()):return b.main(self.args(extra))

    def run_folder(self):return next(p for p in (self.root/'out').iterdir() if p.is_dir())
    def rows(self):return b.recover_rows(self.run_folder()/'predictions.jsonl')
    def summary(self):return json.loads((self.run_folder()/'summary.json').read_text())

    def test_known_video_plan_matches_team_sample_counts_and_union(self):
        c=json.loads((PACKAGE/'team_config.json').read_text())
        plan=e.make_plan({'fps':12,'frame_count':15814},c,True)
        self.assertEqual(len(plan),767)
        self.assertEqual({role:sum(role in p['roles'] for p in plan) for role in ['timeline','table_holdout','prone','people']},
                         {'timeline':659,'table_holdout':131,'prone':84,'people':36})
        self.assertEqual(len({p['frame_index'] for p in plan}),len(plan))
        self.assertEqual(plan[-1]['frame_index'],15813)

    def test_default_is_full_video_with_fixed_model_guide_arguments(self):
        self.assertEqual(self.call(),0)
        rows=self.rows();summary=self.summary()
        self.assertEqual(len(rows),19)
        self.assertEqual(summary['analysis']['sample_counts']['actual']['timeline'],6)
        self.assertEqual(summary['status'],'complete')
        self.assertEqual(len(FakeYOLO.calls),20)
        self.assertEqual(FakeYOLO.calls[0][1],{'imgsz':960,'device':'cpu','verbose':False})
        self.assertEqual(FakeYOLO.calls[1][1],{'imgsz':960,'device':'cpu','verbose':False,'conf':.25,'classes':[0,60]})
        self.assertIsInstance(FakeYOLO.calls[1][0],str)

    def test_auxiliary_samples_do_not_bias_main_timing(self):
        self.call();rows=self.rows()
        for r in rows:r['predict_ms']=10 if 'timeline' in r['roles'] else 10000
        s=json.loads((self.run_folder()/'settings.json').read_text())
        a=e.analyse(rows,s)
        self.assertEqual(a['timing']['whole_video']['predict_ms']['mean'],10)
        self.assertGreater(a['timing']['all_unique']['predict_ms']['mean'],1000)

    def test_auxiliary_frames_do_not_advance_confirmation_or_counter(self):
        c=copy.deepcopy(self.config)
        def r(t,present,roles):return {'time_s':t,'frame_index':round(t*12),'roles':roles,
            'detections':[{'class_id':0,'confidence':.9,'xyxy':[0,0,100,100]}] if present else []}
        rows=[r(0,True,['timeline']),r(.1,True,['prone']),r(.2,True,['prone']),r(1,True,['timeline']),r(2,False,['timeline'])]
        t=e.counters(rows,c)
        self.assertEqual([x['state'] for x in t],['yellow','red','yellow'])
        self.assertEqual(t[0]['streak'],1)
        self.assertEqual(len(t),3)

    def test_scenario_scoring_and_duplicates(self):
        self.call();a=self.summary()['analysis']
        self.assertEqual((a['table']['success'],a['table']['n']),(1,1))
        self.assertEqual((a['prone']['success'],a['prone']['n']),(12,12))
        self.assertEqual((a['people']['success'],a['people']['n']),(12,12))
        self.assertEqual(a['occupancy']['missed_presence'],0)
        self.assertEqual(a['occupancy']['false_presence'],0)

    def test_table_uses_highest_confidence_candidate_not_best_iou(self):
        self.call();rows=self.rows();s=json.loads((self.run_folder()/'settings.json').read_text())
        for r in rows:
            if 'table_holdout' in r['roles']:
                r['detections'].append({'class_id':60,'confidence':.99,'xyxy':[0,0,10,10]})
        self.assertEqual(e.analyse(rows,s)['table']['success'],0)

    def test_unknown_video_does_not_apply_spatial_or_count_references(self):
        self.config['reference']['source_sha256']='wrong';self.cfg.write_text(json.dumps(self.config))
        self.call();a=self.summary()['analysis']
        self.assertFalse(a['table']['available']);self.assertFalse(a['prone']['available'])
        self.assertFalse(a['occupancy']['available'])
        self.assertEqual(a['sample_counts']['actual']['people'],0)

    def test_report_is_team_tables_without_metadata_or_presentation_text(self):
        self.call();folder=self.run_folder()
        md=(folder/'report.md').read_text();html=(folder/'report.html').read_text()
        self.assertIn('| 모델 | 장치 | 표본 | 평균 ms/장 |',md)
        self.assertIn('| 모델 | 테이블 (뒤 20%) | 엎드린 사람 |',md)
        self.assertIn('| 모델 | 빨강 | 노랑 |',md)
        for text in ['7페이지','135ms','155ms','weights_sha256','runner_sha256','메타데이터','/home/']:
            self.assertNotIn(text,md);self.assertNotIn(text,html)
        self.assertIn('추정 기준',md)
        self.assertTrue((folder/'metadata.json').exists())

    def test_partial_resume_and_completed_idempotence(self):
        FakeYOLO.stop_at=4;self.call();folder=self.run_folder();before=self.rows()
        self.assertEqual(len(before),3);self.assertEqual(self.summary()['status'],'interrupted')
        FakeYOLO.calls=[];FakeYOLO.stop_at=None
        self.assertEqual(self.call(['--resume',str(folder)]),0)
        after=self.rows();self.assertEqual(after[:3],before)
        self.assertEqual(len(FakeYOLO.calls),len(after)-3+1)
        calls=len(FakeYOLO.calls);self.call(['--resume',str(folder)])
        self.assertEqual(len(FakeYOLO.calls),calls)
        self.assertEqual(self.summary()['status'],'complete')

    def test_hard_exit_recovery_ignores_stale_checkpoint(self):
        driver="""import sys,types
from unittest.mock import patch
import test_team_benchmark as t
import pi_team_benchmark as b
t.FakeYOLO.hard_stop_at=4
with patch.dict(sys.modules,{'torch':t.FAKE_TORCH,'ultralytics':types.SimpleNamespace(YOLO=t.FakeYOLO)}):
 b.main(__import__('json').loads(sys.argv[1]))
"""
        env=os.environ.copy();env['PYTHONPATH']=os.pathsep.join([str(Path(__file__).parent),str(PACKAGE),'/tmp/pi_team_test_deps'])
        result=subprocess.run([sys.executable,'-c',driver,json.dumps(self.args())],env=env,capture_output=True,text=True,timeout=20)
        self.assertEqual(result.returncode,75,result.stderr)
        folder=self.run_folder();before=self.rows();self.assertEqual(len(before),2)
        (folder/'checkpoint.json').write_text('{"samples":0}')
        self.call(['--resume',str(folder)])
        self.assertEqual(self.rows()[:2],before)
        self.assertEqual(self.summary()['status'],'complete')
        self.assertEqual(len({r['frame_index'] for r in self.rows()}),19)

    def test_resume_rejects_changed_input_files(self):
        FakeYOLO.stop_at=3;self.call();folder=self.run_folder()
        self.weights.write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'변경'):self.call(['--resume',str(folder)])
        self.weights.write_bytes(b'fake model')
        next((folder/'frames').glob('*.jpg')).write_bytes(b'changed JPEG')
        with self.assertRaisesRegex(ValueError,'JPEG'):self.call(['--resume',str(folder)])

    def test_save_only_without_ml_packages_or_source(self):
        FakeYOLO.stop_at=3;self.call();folder=self.run_folder();self.video.unlink();self.weights.unlink()
        with patch.dict(sys.modules,{'cv2':None,'torch':None,'ultralytics':None}):
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(b.main(['--resume',str(folder),'--save-only']),0)
        self.assertEqual(self.summary()['status'],'interrupted')

    def test_torn_tail_preserved_but_interior_corruption_rejected(self):
        p=self.root/'raw.jsonl';p.write_bytes(b'{"index":0}\n{"index":1')
        self.assertEqual(b.recover_rows(p),[{'index':0}])
        self.assertTrue(list(self.root.glob('discarded_tail_*.bin')))
        p.write_bytes(b'{"index":0}\nno JSON\n')
        with self.assertRaises(ValueError):b.recover_rows(p)

    def test_actual_threads_recorded_after_backend_setup(self):
        self.call(['--threads','4'])
        metadata=json.loads((self.run_folder()/'metadata.json').read_text())
        self.assertEqual(metadata['sessions'][0]['torch_threads_during_inference'],4)

    def test_video_mode_keeps_actual_original_frames(self):
        self.call(['--input-mode','video'])
        self.assertTrue(all(isinstance(source,np.ndarray) for source,_ in FakeYOLO.calls))
        self.assertEqual(self.summary()['analysis']['occupancy']['false_presence'],0)
        self.assertFalse((self.run_folder()/'frames').exists())

    def test_state_machine_matches_original_server_ast(self):
        tree=ast.parse((PACKAGE/'team_reference/server.py').read_text())
        loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.iter,ast.Call)
                  and isinstance(n.iter.func,ast.Name) and n.iter.func.id=='frames')
        nodes=[]
        for node in loop.body:
            s=ast.unparse(node)
            if s.startswith('streak =') or isinstance(node,ast.If) and (s.startswith('if streak >= args.confirm or') or s.startswith('if streak >= args.confirm:')):nodes.append(node)
        self.assertEqual(len(nodes),3)
        code=compile(ast.Module(body=nodes,type_ignores=[]),'original_server','exec')
        a={'streak':0,'last_seen':None,'args':types.SimpleNamespace(th=.3,confirm=2,limit_min=30)}
        streak,last=0,None
        for t,conf in [(0,.9),(2,.9),(4,.1),(6,.9),(8,.1),(1804,.1),(1806,.9),(1808,.9)]:
            a.update(t=t,conf=conf);exec(code,a)
            streak,last,state=state_step(streak,last,t,conf)
            self.assertEqual((streak,last,state),(a['streak'],a['last_seen'],a['new']))

    def test_polygon_membership_matches_opencv(self):
        poly=self.config['reference']['zone_points']
        for x,y in [(0,0),(320,240),(100,50),(-1,120),(321,240)]:
            expected=cv2.pointPolygonTest(np.array(poly,np.float32),(float(x),float(y)),False)>=0
            self.assertEqual(e.point_in_polygon(x,y,poly),expected)


if __name__=='__main__':unittest.main()
